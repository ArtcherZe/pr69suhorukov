﻿function func(){
$("input:checked").css("background", "gray")
$('input:checked').click(function(){
    var $that = $(this);
    $that.animate({
        width: $that.width() * 2,
        height: $that.height() * 2
    });
});
}
