function addColor1(){
 $("#ch1").css("background", "green")
$("#ch2").css("background", "red"),
$("ch3").css("background", "blue");
