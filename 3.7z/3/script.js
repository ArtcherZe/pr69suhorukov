function func(){
$("input:checked").css("border","1px solid green");
}

